<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Master of Engineer</title>
    <link rel="stylesheet" href="../common/common.css">
  </head>
  <body>
    <div>掲示板をご利用するにあたってログインをお願いします</div><br>
    <form method="post" action="login_check.php">
      <div>登録名</div>
      <input type="text" name="member">
      <div>パスワード</div>
      <input type="password" name="pass"><br><br>
      <input type="submit" value="ログイン">
    </form>
    <hr>
    <p>初めての方はこちらから会員登録をお願いします。</p>
    <a href="member_add.php">会員登録画面へ</a>
  </body>
</html>
