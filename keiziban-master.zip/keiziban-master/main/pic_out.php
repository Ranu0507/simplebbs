<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Master of Engineer</title>
    <link rel="stylesheet" href="../common/common.css">
  </head>
  <body>
    <p>画像のサイズが１Mを超えています。</p>
    <a href="keizi_top.php">スレッド一覧に戻る</a>
  </body>
</html>
