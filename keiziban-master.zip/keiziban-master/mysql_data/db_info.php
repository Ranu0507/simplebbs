<?php
  /*本来ならば非公開の情報です。
  しかしWebに公開する際の隠し方が分からず強硬手段に出ました。反省です。*/
  $SERV="mysql1.php.xdomain.ne.jp";
	$USER="sonsyu0103_ms";
	$PASS="huzimura0103";
	$DBNAME="sonsyu0103_kb";
?>
